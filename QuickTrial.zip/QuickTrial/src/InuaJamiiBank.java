import java.util.Scanner;
public class InuaJamiiBank {

    // creating a new scanner
    Scanner sc = new Scanner(System.in);

    // creating an Account class to represent account details
    class Account {
        private String accountNumber;
        private String accountType;
        private double balance;


        // Constructor
        public Account(String accountNumber, String accountType, double balance) {
            this.accountNumber = accountNumber;
            this.accountType = accountType;
            this.balance = balance;
        }

        // creating user class to represent bank user details
        class User {
            private String fullName;
            private String userEmail;
            private String userPassword;
            private String phoneNumber;


            public User(String name, String email, String password) {
                this.fullName = name;
                this.userEmail = email;
                this.userPassword = password;
                this.phoneNumber = phoneNumber;
            }
        }

        // getting and imputing the account class details
        public String getAccountNumber() {
            return accountNumber;
        }

        public String getAccountType() {
            return accountType;
        }

        public double getBalance() {
            return balance;
        }

        // Depositing money into the account
        private static void deposit() {
            int balance = 0;
            System.out.println(" How much do you want to deposit?");
            Scanner deposit = new Scanner(System.in);
            int newDeposit = deposit.nextInt();
            int amount = balance + newDeposit;
            System.out.println("You new balance is: " + amount);
        }

        // Withdrawing money from the account
        private static void withdraw() {
            int balance = 0;
            System.out.println(" How much do you want to withdraw?");
            Scanner withdraw = new Scanner(System.in);
            int moneywithdraw = withdraw.nextInt();
            int amount = balance - moneywithdraw;
            System.out.println("You have Withdraw: " + amount);
        }

        // Transfer money to another different account
        private static void transfer() {


        }

        private static void balance() {

        }

        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            int choice = 0;
            do {
                System.out.println("Choose what you want to do with your account");
                System.out.println("1.Deposit funds");
                System.out.println("2.Withdraw funds");
                System.out.println("3.Transfer funds to another account");
                System.out.println("4.Check my account balance");
                System.out.println("5.Register a new account");

                choice = sc.nextInt();

                switch (choice) {
                    case 1:
                        System.out.println("==============================================================================");
                        deposit();
                        break;
                    case 2:
                        System.out.println("==============================================================================");
                        withdraw();
                        break;
                    case 3:
                        System.out.println("==============================================================================");
                        transfer();
                        break;
                    case 4:
                        System.out.println("==============================================================================");
                        balance();
                        break;
                    case 5:
                        System.out.println("==============================================================================");
                        System.out.println("1.Create a Current Account");
                        System.out.println("2.Create a Savings Account");
                        break;
                }
            } while (choice == 6);
        }
    }
}